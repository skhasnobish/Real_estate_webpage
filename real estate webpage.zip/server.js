const express = require('express');
const app = express();
var http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
var redis = require("redis");

client = redis.createClient({
    url: "redis://redis-11332.c81.us-east-1-2.ec2.cloud.redislabs.com:11332",
    password: "QjfLPvJukgraYvANqbnH6r3hYSHK5HtU"
});

client.connect();
client.on("error", function(err) {
  console.log("Error: " + err)
})

const data = 
[
  {address: "224 EAST 25TH ST",
   postal_code: "L8V 3A5",
   city: "Hamilton",
   community: "Mountain",
   province: "Ontario",
   price: 779900,
   bedrooms: 4,
   bathrooms: 3,
   img: "224east.jpeg",
   description: "Beautiful 100% Turn-Key 1.5 Storey Home On East Mountain Feat 3+1 Beds, 3 Baths, In-Law Suite W/ Duplex Conversion Potential, Ample Storage Space, Detached Garage, Up To 5 Car Parking, & Waterproofed Bsmt."
  }, 

  {address: "183 Kitty Murray Lane",
   postal_code: "L9K 1H7",
   city: "Hamilton",
   community: "Ancaster",
   province: "Ontario",
   price: 1050000,
   bedrooms: 4,
   bathrooms: 4,
   img: "183kitty.jpeg",
   description: "Steps to Meadowlands,schools, parks and easy access to 403/LINC. 2 Storey, 3+1 bedrm,3.5 baths with large backyard. Hardwood stairs and hardwood floors in all principal and bed rooms, no carpet! "
  },   

  {address: "20 ERINGATE Court",
   postal_code: "L8J 3Y4",
   city: "Hamilton",
   community: "Stoney Creek",
   province: "Ontario",
   price: 1925000,
   bedrooms: 4,
   bathrooms: 4,
   img: "20eringate.jpeg",
   description: "Built by award winning Zeina Homes. All brick on the sides and rear. Modern open concept main floor has 9ft ceiling, oak staircase with iron spindles, hardwood floors on main level and upper hallways, oversized windows, large kitchen with custom extended height cabinets, granite counters, large island, stainless steel appliances and porcelain tiles."
  },     

  {address: "11 Cloverhill Avenue",
   postal_code: "L8J 3Y4",
   city: "Hamilton",
   community: "Dundas",
   province: "Ontario",
   price: 899900,
   bedrooms: 3,
   bathrooms: 3,
   img: "11cloverhill.jpeg",
   description: "Fabulous home and property in sought after Dundas neighborhood. Superb location on a quiet cul de sac just a short walk to downtown Dundas's shops, restaurants and amenities."
  },   

  {address: "257 PARKSIDE Drive Unit# 8",
   postal_code: "L8B 0W5",
   city: "Hamilton",
   community: "Waterdown",
   province: "Ontario",
   price: 799900,
   bedrooms: 2,
   bathrooms: 3,
   img: "257parkside.jpeg",
   description: "This condo townhome boasts two huge bedrooms, both with 4-piece ensuite bathrooms. The laundry is also on the bedroom level with custom California Closet built-ins around it. The main floor is stunning! Open concept living/dining room and kitchen with a breakfast bar."
  },   

];

app.get('/', function(req, res) {
  res.sendFile(__dirname + "/home.html");
});

app.get('/search', function(req,res) {

  res.sendFile(__dirname + "/search.html")

});

app.get('/community_search', function(req,res){

  res.json(data.filter( (house) => house.community == req.query.community));

});

app.get('/price_search', function(req,res) {

  res.json(data.filter( (house) => (house.price <= req.query.max && 
                                    house.price >= req.query.min) ));

});

app.get('/bed_search', function(req,res) {

  res.json(data.filter( (house) => (house.bedrooms >= req.query.bedrooms )));

});

app.get('/bathroom_search', function(req,res) {

  res.json(data.filter( (house) => (house.bathrooms >= req.query.bathrooms )));

});

app.get('/all', function(req,res) {

  res.json(data);

});

async function redisLog(msg) {
  let exists = await client.exists("redis_log");

  let redis_log;
  if (exists == 0)
  {
    redis_log = 1;
    await client.set("redis_log", redis_log);
  }
  else 
  {
    redis_log = await client.get("redis_log");
  }

  await client.set("log:" + redis_log, msg);
  await client.set("redis_log", parseInt(redis_log) + 1);
}

async function helpLog(msg) {
  let exists = await client.exists("help_log");

  let help_log;
  if (exists == 0)
  {
    help_log = 1;
    await client.set("help_log", help_log);
  }
  else 
  {
    help_log = await client.get("help_log");
  }

  await client.set("help_log:" + help_log, "ID: " + help_log + ", Command: " + msg);
  await client.set("help_log", parseInt(help_log) + 1);
}

async function bathroomsLog(msg) {
  let exists = await client.exists("bathrooms_log");

  let bathrooms_log;
  if (exists == 0)
  {
    bathrooms_log = 1;
    await client.set("bathrooms_log", bathrooms_log);
  }
  else 
  {
    bathrooms_log = await client.get("bathrooms_log");
  }

  await client.set("bathrooms_log:" + bathrooms_log, "ID: " + bathrooms_log + ", Command: " + msg);
  await client.set("bathrooms_log", parseInt(bathrooms_log) + 1);
}

async function bathroomsBedroomsLog(msg) {
  let exists = await client.exists("bathrooms_bedrooms_log");

  let bathrooms_bedrooms_log;
  if (exists == 0)
  {
    bathrooms_bedrooms_log = 1;
    await client.set("bathrooms_bedrooms_log", bathrooms_bedrooms_log);
  }
  else 
  {
    bathrooms_bedrooms_log = await client.get("bathrooms_bedrooms_log");
  }

  await client.set("bathrooms_bedrooms_log:" + bathrooms_bedrooms_log, "ID: " + bathrooms_bedrooms_log + ", Command: " + msg);
  await client.set("bathrooms_bedrooms_log", parseInt(bathrooms_bedrooms_log) + 1);
}

async function bedroomsLog(msg) {
  let exists = await client.exists("bedrooms_log");

  let bedrooms_log;
  if (exists == 0)
  {
    bedrooms_log = 1;
    await client.set("bedrooms_log", bedrooms_log);
  }
  else 
  {
    bedrooms_log = await client.get("bedrooms_log");
  }

  await client.set("bedrooms_log:" + bedrooms_log, "ID: " + bedrooms_log + ", Command: " + msg);
  await client.set("bedrooms_log", parseInt(bedrooms_log) + 1);
}

async function contactLog(msg) {
  let exists = await client.exists("contact_log");

  let contact_log;
  if (exists == 0)
  {
    contact_log = 1;
    await client.set("contact_log", contact_log);
  }
  else 
  {
    contact_log = await client.get("contact_log");
  }

  await client.set("contact_log:" + contact_log, "ID: " + contact_log + ", Command: " + msg);
  await client.set("contact_log", parseInt(contact_log) + 1);
}

io.on('connection', (socket) => {

  socket.on("chat message", function(msg) {
    redisLog(msg.trim());
    
    let cmd = msg.trim().split(' ');
    let response = "";
    let result;
    console.log(msg);
    console.log(cmd);

    if(cmd[0] == "bathrooms" && Number.isInteger( parseInt(cmd[1]))) {
      bathroomsLog(msg.trim());
      result = data.filter( element => {return element.bathrooms >= cmd[1]});
      response += "Here's what we found: " + result.length + "<br/>";
      result.forEach(element => {response += "Address: " + element.address + "<br/>" + "Postal Code: " + element.postal_code + "<br/>" + "City: " + element.city + "<br/>" + "Community: " + element.community + "<br/>" + "Province: " + element.province + "<br/>" + "Price: " + element.price + "<br/>" + "Bedrooms: " + element.bedrooms + "<br/>" + "Bathrooms: " + element.bathrooms + "<br/>" + "Image: <br/>" + element.img + "'alt='" + element.img + "' width='200'>" + "<br/>" + "Description: " + element.description + "<br/>"});
      if(result.length == 0) {
        response = "Sorry! We could not find what you are looking for. Please try again"}
    }
    else if (cmd[0] == "bathrooms" && Number.isInteger( parseInt(cmd[1])) && cmd[2] == "bedrooms" && Number.isInteger(parseInt(cmd[3]))) {
      bathroomsBedroomsLog(msg.trim());
      result = data.filter( element => {return element.bathrooms >= cmd[1] && element.bedrooms >= cmd[3]});
      response += "Here's what we found: " + result.length + "<br/>";
      result.forEach(element => {response += "Address: " + element.address + "<br/>" + "Postal Code: " + element.postal_code + "<br/>" + "City: " + element.city + "<br/>" + "Community: " + element.community + "<br/>" + "Province: " + element.province + "<br/>" + "Price: " + element.price + "<br/>" + "Bedrooms: " + element.bedrooms + "<br/>" + "Bathrooms: " + element.bathrooms + "<br/>" + "Image: <br/>" + element.img + "'alt='" + element.img + "' width='200'>" + "<br/>" + "Description: " + element.description + "<br/>"});
      if(result.length == 0) {
        response = "Sorry! We could not find what you are looking for. Please try again"}
    }

    else if (cmd[0] == "bedrooms" && Number.isInteger( parseInt(cmd[1]))) {
      bedroomsLog(msg.trim());
      result = data.filter( element => {return element.bedrooms >= cmd[1]});
      response += "Here's what we found: " + result.length + "<br/>";
      result.forEach(element => {response += "Address: " + element.address + "<br/>" + "Postal Code: " + element.postal_code + "<br/>" + "City: " + element.city + "<br/>" + "Community: " + element.community + "<br/>" + "Province: " + element.province + "<br/>" + "Price: " + element.price + "<br/>" + "Bedrooms: " + element.bedrooms + "<br/>" + "Bathrooms: " + element.bathrooms + "<br/>" + "Image: <br/>" + element.img + "'alt='" + element.img + "' width='200'>" + "<br/>" + "Description: " + element.description + "<br/>"});
      if(result.length == 0) {
        response = "Sorry! We could not find what you are looking for. Please try again"}
    }

    else if (cmd[0] == "contact") {
      contactLog(msg.trim());
      response += "<h3>Contact Page: </h3>" + "<br/>" +
                  "<strong>Customer service is available on Monday to Sunday from 9am to 5pm.</strong>" +
                  "by phone: +1(111)111-111" +
                  "by email: care@hamiltonhomes.ca"
    } 
    
    else if (cmd[0] =="help") {
      helpLog(msg.trim());
      response = "<h2>Here is a list of potential commenads: <h2> <br/>" + "Note: # represents any number that you enter </br>" +
                  "<strong> bathrooms # </strong>: show all houses with # or more bathrooms. For eg 'bathrooms 3' show all houses with 3 or more bathrooms <br/>" +
                  "<strong> bathrooms # bedrooms # </strong>: show all houses with # or more bathrooms, # or more bedrooms. For eg 'bathrooms 3 bedrooms 2' shows all houses with 3 or more bathrooms, 2 or more bedrooms <br/>" +
                  "<strong> bedrooms # </strong>: show all houses with # or more bedrooms. For eg 'bedrooms 3' show all houses with 3 or more bedrooms <br/>" +
                  "<strong> Contact <strong/>: Shows the contact information ie phone number and email address <br/>" + 
                  "<strong> Help <strong/>: shows a listing of all comands <br/>" +
                  "If you have any other questions, please don't hesitate to reach us through phone or email and we will be be happy to assist you <br/>"}
                  
                  else if (cmd[0] == "") {
                    response = "Sorry! We didn't get any message, so we are unable to assist you. Please type a message and then click send"                    
                  }

                  else {
                    response = "Sorry! The chatbox is in early stage of development, so it can't answer a variety of questions. Type 'help' to see a list of available commands OR contact us directly"}
                    response = "<li>" + response + "</li><br/>" + "<li>Is there anything else that we can help you with? Please type it in the chatbox</li>";
                    io.emit("chat message", response);
  });

  socket.on('disconnect', () => {
  });

});


// Send back a static file
// Use a regular expression to detect "any other route"
// Define the route last such that other routes would
// be detected and handled as such first.
app.get(/^(.+)$/, function(req,res){
  console.log("static file request: " + req.params[0]);
  res.sendFile(__dirname + req.params[0]);
});



server.listen(3000, function()
{
  console.log("App listening....");
});
