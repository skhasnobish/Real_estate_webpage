$(document).ready(function() {

  let all = $("#all");

  let mountain = $("#mountain");
  let ancaster = $("#ancaster");
  let stoneycreek = $("#stoneycreek");
  let dundas = $("#dundas");
  let waterdown = $("#waterdown");

  let bedroomdropdown = $("#bedroomdropdown");
  let bedroomfilterbtn = $("#bedroomfilterbtn");
  let bathroomdropdown = $("#bathroomdropdown");
  let bathroomfilterbtn = $("#bathroomfilterbtn");

  let minpriceInput = $("#minpriceInput");
  let maxpriceInput = $("#maxpriceInput");
  let pricebtn = $("#pricebtn");

  let realestateTable = ("#realestateTable");

  function fillTable(data) {
    console.log("filling")
    let criteria = '<thead><tr>' +
  'th scope="col">Address</th>' +
  'th scope="col">Postal Code</th>' +
  'th scope="col">City</th>' +
  'th scope="col">Community</th>' +
  'th scope="col">Province</th>' +
  'th scope="col">Price</th>' +
  'th scope="col">Bedrooms</th>' +
  'th scope="col">Bathrooms</th>' +
  'th scope="col">Image</th>' +
  'th scope="col">Description</th>' +
  '</tr></thead>' +
  '<tbody>';
  
  for (let i = 0; i < data.length; i++) {
    criteria += '<tr>' +
    '<td>' + data[i].address + '</td>' +
    '<td>' + data[i].postal_code + '</td>' +
    '<td>' + data[i].city + '</td>' +
    '<td>' + data[i].community + '</td>' +
    '<td>' + data[i].province + '</td>' +
    '<td>' + data[i].price + '</td>' +
    '<td>' + data[i].bedrooms + '</td>' +
    '<td>' + data[i].bathrooms + '</td>' +
    '<td>' + '<img src="' + data[i].img + '" alt="' + data[i].img + '">' + '</td>' +
    '<td>' + data[i].description + '</td>' +
    '</tr>';
  }
  criteria += '</tbody>';
  console.log("pringitn data below")
  console.log(criteria)
  $("#realestateTable").html(criteria);

}

function allData() {
  console.log("allData clicked");
  $.get("http://localhost:3000/all",
  function(data) {
    fillTable(data);
  },
"json");
}

function bathroomData() {
  $.get("http://localhost:3000/bathroom_search",
  {"bathrooms" : bathroomdropdown.val()},
  function(data) {
    fillTable(data);
  },
"json");
}

function bedroomData() {
  $.get("http://localhost:3000/bed_search",
  {"bedrooms" : bedroomdropdown.val()},
  function(data) {
    fillTable(data);
  },
"json");
}

function priceData() {
  $.get("http://localhost:3000/price_search",
  {"min": minpriceInput.val(), "max": maxpriceInput.val()},
  function(data) {
    fillTable(data);
},
"json");
}

function communityData(communityName) {
  console.log("click")
  $.get("http://localhost:3000/community_search",
  {"community" : communityName},
  function(data) {
    fillTable(data);
  },
  "json");
}

allData();
all.click(allData);
mountain.click(function() {
  console.log("click")
  return communityData(mountain.text()); });
ancaster.click(function() {return communityData(ancaster.text()); });
stoneycreek.click(function() {return communityData(stoneycreek.text()); });
dundas.click(function() {return communityData(dundas.text()); });
waterdown.click(function() {return communityData(waterdown.text()); });

bedroomfilterbtn.click(bedroomData);
bathroomfilterbtn.click(bathroomData);
pricebtn.click(priceData);

});

