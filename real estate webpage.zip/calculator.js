var criteria = document.getElementById('criteria');
var reset = document.getElementById('Reset');
var alert = document.getElementById('Alert');
var trigger = document.getElementById('Calculate');

function check_Mortgage()
{
    let Mortgage_Amount = document.getElementById('Mortgage_Amount')
    if (isNaN(Mortgage_Amount.value) || Mortgage_Amount.value <= 0 || Mortgage_Amount.value == "")
    {
        Mortgage_Amount.classList.remove("is-valid")
        Mortgage_Amount.classList.add("is-invalid")
        alert.innerHTML += "Mortgage Amount must be a positive number. "
        return "Mortgage Amount must be a positive number."
        
    } 
    else {
        Mortgage_Amount.classList.remove("is-invalid");
        Mortgage_Amount.classList.add("is-valid");
        return parseFloat(Mortgage_Amount.value);
    }
}

function check_Interest()
{
    let Interest_Rate = document.getElementById('Interest_Rate')
    if (isNaN(Interest_Rate.value) || Interest_Rate.value <=0 || Interest_Rate.value == "")
    {
        Interest_Rate.classList.remove("is-valid")
        Interest_Rate.classList.add("is-invalid")
        alert.innerHTML += "Interest Rate must be a positive number. "
        return "Interest Rate must be a positive number. "
   
    }
    else {
        Interest_Rate.classList.remove("is-invalid");
        Interest_Rate.classList.add("is-valid");
        return parseFloat(Interest_Rate.value);
    }
}

function check_Loan()
{
    let Loan_Length = document.getElementById('Loan_Length')
    let Loan_integer = Number(Loan_Length.value)
    if (Loan_Length.value <5 || Loan_Length.value >30 || Number.isInteger(Loan_integer) == false || Loan_Length.value == "")
    {
        Loan_Length.classList.remove("is-valid")
        Loan_Length.classList.add("is-invalid")
        alert.innerHTML += "Loan Length must be between 5-30 years"
        return "Loan Length must be between 5-30 years"
    }
    else {
        Loan_Length.classList.remove("is-invalid");
        Loan_Length.classList.add("is-valid");
        return parseInt(Loan_Length.value);
    }
}
function check_Postal()
{
    let Postal_Code = document.getElementById('Postal_Code')
    if (Postal_Code.value.startsWith("L",0) == false || Postal_Code.value.length != 7)
    {
        Postal_Code.classList.remove("is-valid")
        Postal_Code.classList.add("is-invalid")
        alert.innerHTML += "Must be located in Hamilton"
        return "Must be located in Hamilton"
    }
    else {
        Postal_Code.classList.remove("is-invalid");
        Postal_Code.classList.add("is-valid");
        return true;
    }
}

function get_answer() {
    reset_all();
    check_Mortgage();
    check_Interest();
    check_Loan();
    check_Postal();
    event.preventDefault();
}

function reset_all() {
    let Mortgage_Amount = document.getElementById("Mortgage_Amount");
    let Interest_Rate = document.getElementById("Interest_Rate");
    let Loan_Length = document.getElementById("Loan_Length");
    let Postal_Code = document.getElementById("Postal_Code");

    Mortgage_Amount.value = "";
    Interest_Rate.value = "";
    Loan_Length.value = "";
    Postal_Code.value = "";
    alert.innerHTML = "";
    Mortgage_Amount.classList.remove("is-valid");
    Mortgage_Amount.classList.remove("is-invalid");
    Interest_Rate.classList.remove("is-valid");
    Interest_Rate.classList.remove("is-invalid");
    Loan_Length.classList.remove("is-valid");
    Loan_Length.classList.remove("is-invalid");
    Postal_Code.classList.remove("is-valid");
    Postal_Code.classList.remove("is-invalid");
}




    if (trigger) {
        trigger.addEventListener('click', function() {
    
            let Mortgage_Amount = check_Mortgage();
            let Interest_Rate = check_Interest();
            let Loan_Length = check_Loan();
            let postal_Code = check_Postal();
            var message = "";
            message += "<ul>";
            if (isNaN(Mortgage_Amount) == true) message += "<li>" + Mortgage_Amount + "</li>"
            if (isNaN(Interest_Rate) == true) message += "<li>" + Interest_Rate + "</li>"
            if (isNaN(Loan_Length) == true) message += "<li>" + Loan_Length + "</li>"
            if (postal_Code != true) message += "<li>" + postal_Code  + "</li>"
            message += "</ul>";
            if (isNaN(Mortgage_Amount) == true || isNaN(Interest_Rate) == true || isNaN(Loan_Length) == true || postal_Code != true)
            {
              //  alert(message, 'danger');
              //alert.innerHTML = "hi there i am here find me"
              alert.innerHTML = "<div class='alert alert-danger' role='alert'>" + message + "</div>";
              //console.log("Hello. Please enter your data in appropriate fields to get accurate calculations. ", "danger");
            }
    
            else {
                Interest_Rate =  parseFloat(Interest_Rate/100);
                Loan_Length = Loan_Length * 12;
                let monthly_payment = Mortgage_Amount * (Interest_Rate/12) * (Math.pow(1+(Interest_Rate/12), Loan_Length))/(Math.pow(1+(Interest_Rate/12), Loan_Length)-1)
               // alert("Your estimated monthly mortgage payment is: " + monthly_payment)
               alert.innerHTML = "<div class='alert alert-success' role='alert'>" + "Your estimated monthly mortgage payment is: $"+monthly_payment.toFixed(2)+ ". success" + "</div>"
            }
        })
    }

trigger.addEventListener('submit', get_answer);
reset.addEventListener('click', reset_all);