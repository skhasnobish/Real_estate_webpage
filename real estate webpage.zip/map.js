let markers = [];


function populatehospitalsdatat(datapass)
  {
    map = new google.maps.Map(document.getElementById("map"),
    {
      center: {lat: 43.252642721032785, lng: -79.83092125967038},
      zoom: 12,map: map,
    });
  infoWindow = new google.maps.InfoWindow();
    click_marker = function()
    {
      infoWindow.close();
      infoWindow.setContent(this.NAME);
      infoWindow.open(map, this);
    }


    for (let i = 0; i < datapass.features.length; i++) {
      hospitals_marker = new google.maps.Marker({
        position: {lat: parseFloat(datapass.features[i].properties.LATITUDE),
        lng: parseFloat(datapass.features[i].properties.LONGITUDE)},
        title: datapass.features[i].properties.NAME
      });

      hospitals_marker.setMap(map);
      hospitals_marker.NAME = datapass.features[i].properties.NAME;
      hospitals_marker.CATEGORY = datapass.features[i].properties.CATEGORY;
      markers.push(hospitals_marker);

      google.maps.event.addListener(hospitals_marker, "click", click_marker);
    }



  }


function clearsss() 
{
  console.log("in clear function")
  for (let i = 0; i < markers.length; i++) {
    markers[i].setMap(null);
  }

}

function callingwaterfalls()
{
  clearsss() 
  populatehospitalsdatat(waterfalls)


}

function callingschools()
{
  clearsss() 
  populatehospitalsdatat(schools)


}


function callingfirestations()
{
    clearsss() 

    populatehospitalsdatat(firestations)

}


function callinghospital()
{
  clearsss() 
  populatehospitalsdatat(hospitals)
}

  let hospitalsbtnpress = $("#hospitals");
  let fire_stationsbtnpress = $("#fire_stations");
  let waterfallsbuttonpress = $("#waterfalls");
  let schoolsbuttonpress = $("#schools");
  let clearbuttonpress = $("#clear");
  hospitalsbtnpress.click(callinghospital)
  fire_stationsbtnpress.click(callingfirestations)
  waterfallsbuttonpress.click(callingwaterfalls)
  schoolsbuttonpress.click(callingschools)
  clearbuttonpress.click(clearsss)